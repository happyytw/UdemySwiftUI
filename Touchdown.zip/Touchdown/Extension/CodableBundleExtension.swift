//
//  CodableBundleExtension.swift
//  Touchdown
//
//  Created by Taewon Yoon on 2023/09/01.
//

import Foundation

extension Bundle {
    func decode<T: Codable>(_ file: String) -> T {
        guard let url = self.url(forResource: file, withExtension: nil) else {
            fatalError("\(file) 찾는거 에러")
        }
        
        guard let data = try? Data(contentsOf: url) else {
            fatalError("\(file)을 로드하는거 에러")
        }
        
        let decoder = JSONDecoder()
        
        guard let loaded = try? decoder.decode(T.self, from: data) else {
            fatalError("디코드 에러")
        }
        
        return loaded
    }
}
