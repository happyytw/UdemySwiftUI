//
//  TouchdownApp.swift
//  Touchdown
//
//  Created by Taewon Yoon on 2023/09/01.
//

import SwiftUI

@main
struct TouchdownApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(Shop()) // environmentObject는 공유되는 데이터에 의존하는 view들을 만드는 것을 허용한다.
                                           // 위에처럼 선언하면 shop 클래스를 어느곳에서든 접근할 수 있게된다
        }
    }
}
