//
//  PlayerModel.swift
//  Touchdown
//
//  Created by Taewon Yoon on 2023/09/01.
//

import Foundation

struct Player: Codable, Identifiable {
    let id: Int
    let image: String
}
