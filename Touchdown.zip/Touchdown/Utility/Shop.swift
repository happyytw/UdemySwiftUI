//
//  Shop.swift
//  Touchdown
//
//  Created by Taewon Yoon on 2023/09/02.
//

import Foundation

// 클래스 내부에 객체들이 모든 view에서 사용될 수 있도록 해준다. 그래서 만약 값이 바뀌면 view는 업데이트 된다.
// 그러기 위해서는 swiftUI 프레임워크에 어떤 데이터를 지속적으로 관찰해야하는지 알려줘야한다.
// 그러기 위해서는 @Published 를 선언해야한다. 선언되면 값이 변화됐을때 뷰를 업데이트한다.
class Shop: ObservableObject {
    
    @Published var showingProduct: Bool = false
    @Published var selectedProduct: Product? = nil
    
}
